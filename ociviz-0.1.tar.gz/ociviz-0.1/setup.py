import os
import glob
from setuptools import setup, find_packages
 
print find_packages()

data_files = []
directories =  [x[0] for x in os.walk("static")]
for directory in directories:
    files = glob.glob(os.path.join(directory,'*'))
    data_files.append((directory, files))

data_files.append('start_server.cmd')
data_files.append('start_server.sh')
data_files.append('README.md')

setup(
     name='ociviz',    # This is the name of your PyPI-package.
     version='0.1',                          # Update the version number for new releases
     scripts=['ociviz.py','ocivizserver.py'],                 # The name of your scipt, and also the command you'll be using for calling it
	 author='Michel Benoliel',
	 author_email='michel.benoliel@oracle.com',
	 description="OCI Visualization tool",
	 data_files=data_files,
	 packages=find_packages(),
	 install_requires=[
		'datetime',
		'json'
		'oci',
		'netaddr',
		'ConfigParser',
		'argparse',
		'flask',
		'flask_cors',
		'os',
		'urllib',
		'traceback',
		'netaddr'
      ]	 

)

